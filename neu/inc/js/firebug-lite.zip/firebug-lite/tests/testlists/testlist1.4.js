FBTest.loadTestList([
    /* Firebug */
    { page: "content/firebug/4239/issue4239.html" },
    
    /* XHR */
    { page: "content/xhr/2756/issue2756.html" },
    { page: "content/xhr/2840/issue2840.html" },
    { page: "content/xhr/2846/issue2846.html" },
    { page: "content/xhr/2977/issue2977.html" },
    { page: "content/xhr/3504/issue3504.html" },
    { page: "content/xhr/4472/issue4472.html" },

    /* CSS */
    { page: "content/css/3262/issue3262.html" },
    { page: "content/css/3326/issue3326.html" },
    { page: "content/css/4776/issue4776.html" },
    { page: "content/css/4777/issue4777.html" }
]);